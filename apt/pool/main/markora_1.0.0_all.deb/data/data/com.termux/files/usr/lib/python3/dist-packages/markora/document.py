"""
Task and TodoDocument Markdown Model
"""

import os
import re
import datetime
import tempfile
from .config import get_todo_file

TASK_REGEX = re.compile(r"^(\s*[-*+]\s*\[)([ xX])(\]\s*)(.*)$")


class Task:
    def __init__(self, task_id, line_idx, done, text, indent, section):
        self.id = task_id
        self.line_idx = line_idx
        self.done = done
        self.text = text
        self.indent = indent
        self.section = section
        self.sublines = []
        self.priority = ""
        self.tags = []
        self._parse_metadata()

    def _parse_metadata(self):
        # Extract priority like P1, P2, P3 or #p1, @p1, (A), (B)
        p_match = re.search(r"\b(P[0-9]+|\([A-E]\))\b", self.text, re.IGNORECASE)
        if p_match:
            self.priority = p_match.group(1).upper()
        # Extract tags
        tags = re.findall(r"(#[a-zA-Z0-9_\-]+|@[a-zA-Z0-9_\-]+|\+[a-zA-Z0-9_\-]+)", self.text)
        self.tags.extend(tags)

    def add_subline(self, line):
        self.sublines.append(line)
        p_match = re.search(r"(?:Priority|Prio)[\s*:]+([Pp][0-9]+|\([A-E]\))", line)
        if p_match:
            self.priority = p_match.group(1).upper()

    @property
    def clean_title(self):
        """Title without trailing priority suffix to avoid double badge rendering."""
        if not self.priority:
            return self.text
        cleaned = re.sub(r"\s*\[" + re.escape(self.priority) + r"\]\s*$", "", self.text, flags=re.IGNORECASE)
        return cleaned.strip()

    @property
    def continuation_lines(self):
        """Non-bullet indented continuation lines belonging to the task body."""
        conts = []
        for s in self.sublines:
            if re.match(r"^[-*+]\s+", s) or re.match(r"^[0-9]+\.\s+", s):
                break
            if self.priority and re.match(r"^[-*]?\s*\*\*Priority\*\*:\s*" + re.escape(self.priority) + r"$", s.strip(), re.IGNORECASE):
                continue
            if re.match(r"^[-*]?\s*(?:Priority|Prio)[\s*:]+", s, re.IGNORECASE):
                continue
            cleaned_s = s
            if self.priority:
                cleaned_s = re.sub(r"\s*\[" + re.escape(self.priority) + r"\]\s*$", "", s, flags=re.IGNORECASE).strip()
            conts.append(cleaned_s)
        return conts

    @property
    def item_sublines(self):
        """Sub-items (scopes, deliverables, subtasks) excluding continuation lines and priority tags."""
        conts_len = len(self.continuation_lines)
        items = []
        for s in self.sublines[conts_len:]:
            if self.priority and re.match(r"^[-*]?\s*\*\*Priority\*\*:\s*" + re.escape(self.priority) + r"$", s.strip(), re.IGNORECASE):
                continue
            if re.match(r"^[-*]?\s*(?:Priority|Prio)[\s*:]+", s, re.IGNORECASE):
                continue
            items.append(s)
        return items

    @property
    def full_description(self):
        """Full title including continuation lines, without trailing priority badge."""
        base = self.clean_title
        conts = self.continuation_lines
        if conts:
            return base + " " + " ".join(conts)
        return base

    @property
    def full_description_lines(self):
        """List of lines making up the complete description (clean title + continuation lines)."""
        return [self.clean_title] + self.continuation_lines


class TodoDocument:
    def __init__(self, filepath=None):
        if filepath is None:
            filepath = get_todo_file()
        self.filepath = filepath
        self.lines = []
        self.tasks = []
        self.sections = []
        self.load()

    def load(self):
        if not os.path.exists(self.filepath):
            os.makedirs(os.path.dirname(os.path.abspath(self.filepath)), exist_ok=True)
            initial_content = (
                "# MASTER TODOLIST & STRATEGIC MILESTONES\n\n"
                f"- **Created**: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                "- **Status**: ACTIVE\n\n"
                "---\n\n"
                "## 1. ACTIVE TASKS (0/10)\n\n"
                "## 2. COMPLETED TASKS\n"
            )
            with open(self.filepath, "w", encoding="utf-8") as f:
                f.write(initial_content)

        with open(self.filepath, "r", encoding="utf-8") as f:
            self.lines = f.read().splitlines()

        self.tasks = []
        self.sections = []
        current_section = "General"
        current_task = None
        task_id = 0

        for i, line in enumerate(self.lines):
            if line.startswith("#"):
                current_section = line.strip("#").strip()
                if current_section not in self.sections:
                    self.sections.append(current_section)
                current_task = None
                continue

            m = TASK_REGEX.match(line)
            if m:
                task_id += 1
                indent = len(line) - len(line.lstrip())
                done = m.group(2).lower() == "x"
                text = m.group(4)
                current_task = Task(task_id, i, done, text, indent, current_section)
                self.tasks.append(current_task)
            elif current_task is not None:
                indent = len(line) - len(line.lstrip())
                if line.strip() and indent > current_task.indent:
                    current_task.add_subline(line.strip())
                elif not line.strip():
                    pass
                else:
                    current_task = None

    def save(self):
        """Atomic write to prevent corruption."""
        dir_name = os.path.dirname(os.path.abspath(self.filepath)) or "."
        os.makedirs(dir_name, exist_ok=True)
        with tempfile.NamedTemporaryFile("w", dir=dir_name, delete=False, encoding="utf-8") as tf:
            tf.write("\n".join(self.lines) + "\n")
            temp_path = tf.name
        os.replace(temp_path, self.filepath)
        self.load()

    def get_task(self, task_id):
        for t in self.tasks:
            if t.id == task_id:
                return t
        return None

    def toggle_tasks(self, task_ids, set_done=None):
        """Toggle multiple tasks in a single batch."""
        results = []
        any_modified = False
        for tid in task_ids:
            task = self.get_task(tid)
            if not task:
                results.append((False, f"Task ID {tid} not found."))
                continue

            new_status = not task.done if set_done is None else set_done
            line = self.lines[task.line_idx]
            m = TASK_REGEX.match(line)
            if not m:
                results.append((False, f"Failed to match syntax for Task [{tid}]."))
                continue

            new_char = "x" if new_status else " "
            new_line = f"{m.group(1)}{new_char}{m.group(3)}{m.group(4)}"
            self.lines[task.line_idx] = new_line
            any_modified = True
            results.append((True, f"Task [{tid}] marked as {'[x] DONE' if new_status else '[ ] PENDING'}."))

        if any_modified:
            self.update_section_counters()
            self.save()

        return results

    def toggle_task(self, task_id, set_done=None):
        res = self.toggle_tasks([task_id], set_done=set_done)
        return res[0] if res else (False, "No task provided.")

    def edit_task_text(self, task_id, new_text):
        task = self.get_task(task_id)
        if not task:
            return False, f"Task ID {task_id} not found."
        line = self.lines[task.line_idx]
        m = TASK_REGEX.match(line)
        if not m:
            return False, "Failed to match task line syntax."

        # Count consecutive continuation lines belonging to the previous text
        cont_count = 0
        for j in range(task.line_idx + 1, len(self.lines)):
            sub_l = self.lines[j]
            sub_indent = len(sub_l) - len(sub_l.lstrip())
            stripped = sub_l.strip()
            if stripped and sub_indent > task.indent and not re.match(r"^[-*+]\s+", stripped) and not re.match(r"^[0-9]+\.\s+", stripped):
                cont_count += 1
            else:
                break

        new_lines = new_text.splitlines()
        first_line = new_lines[0] if new_lines else ""
        replacement_lines = [f"{m.group(1)}{m.group(2)}{m.group(3)}{first_line}"]
        for cl in new_lines[1:]:
            if cl.strip():
                replacement_lines.append(f"{' ' * (task.indent + 2)}{cl.strip()}")

        self.lines[task.line_idx:task.line_idx + 1 + cont_count] = replacement_lines
        self.save()
        return True, f"Renamed Task #{task_id}"

    def add_task(self, title, priority="", section=None, scope="", deliverables=""):
        if not self.lines:
            self.load()

        insert_idx = len(self.lines)
        target_section = section

        if not target_section:
            for s in self.sections:
                if "ACTIVE" in s.upper():
                    target_section = s
                    break
            if not target_section and self.sections:
                target_section = self.sections[0]

        if target_section:
            sec_idx = -1
            for i, line in enumerate(self.lines):
                if line.startswith("#") and target_section in line:
                    sec_idx = i
                    break
            
            if sec_idx != -1:
                insert_idx = len(self.lines)
                for i in range(sec_idx + 1, len(self.lines)):
                    if self.lines[i].startswith("#") or self.lines[i].startswith("---"):
                        insert_idx = i
                        break
            else:
                self.lines.append(f"\n## {target_section}\n")
                insert_idx = len(self.lines)

        title_lines = title.strip().splitlines()
        first_title = title_lines[0].strip() if title_lines else ""
        if priority and not re.search(r"\b(P[0-9]+|\([A-E]\))\b", first_title, re.IGNORECASE):
            first_title = f"{first_title} [{priority.upper()}]"

        task_lines = [f"- [ ] {first_title}"]
        for cl in title_lines[1:]:
            if cl.strip():
                task_lines.append(f"  {cl.strip()}")

        if scope:
            task_lines.append(f"  - **Scope**: {scope.strip()}")
        if deliverables:
            task_lines.append(f"  - **Deliverables**: {deliverables.strip()}")

        for offset, l in enumerate(task_lines):
            self.lines.insert(insert_idx + offset, l)

        self.update_section_counters()
        self.save()
        return True, f"Added task: {first_title}"

    def delete_tasks(self, task_ids):
        """Delete multiple tasks safely without cascading ID or line drift."""
        tasks_to_delete = []
        not_found = []
        for tid in task_ids:
            t = self.get_task(tid)
            if t:
                tasks_to_delete.append(t)
            else:
                not_found.append(tid)

        ranges = []
        for t in tasks_to_delete:
            start_idx = t.line_idx
            remove_count = 1
            for i in range(start_idx + 1, len(self.lines)):
                l = self.lines[i]
                indent = len(l) - len(l.lstrip())
                if l.strip() and indent > t.indent:
                    remove_count += 1
                else:
                    break
            ranges.append((start_idx, remove_count, t))

        # Sort descending by start_idx to delete bottom-to-top cleanly
        ranges.sort(key=lambda r: r[0], reverse=True)
        results = []
        for start_idx, count, t in ranges:
            del self.lines[start_idx:start_idx + count]
            results.append((True, f"Deleted task [{t.id}]: {t.text}"))

        for tid in not_found:
            results.append((False, f"Task ID {tid} not found."))

        if ranges:
            self.update_section_counters()
            self.save()

        return results

    def delete_task(self, task_id):
        res = self.delete_tasks([task_id])
        return res[0] if res else (False, f"Task ID {task_id} not found.")

    def update_section_counters(self):
        """Update (X/Y) active counters in section headings."""
        for i, line in enumerate(self.lines):
            if line.startswith("#"):
                m = re.search(r"\(([0-9]+)/([0-9]+)\)", line)
                if m:
                    total_cap = m.group(2)
                    active_count = 0
                    for j in range(i + 1, len(self.lines)):
                        sub_l = self.lines[j]
                        if sub_l.startswith("#") or sub_l.startswith("---"):
                            break
                        tm = TASK_REGEX.match(sub_l)
                        if tm and tm.group(2).lower() != "x":
                            active_count += 1
                    new_line = re.sub(r"\(([0-9]+)/([0-9]+)\)", f"({active_count}/{total_cap})", line)
                    self.lines[i] = new_line
